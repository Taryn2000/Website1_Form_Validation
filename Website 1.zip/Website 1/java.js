const form= document.getElementById('form');
const fName = document.getElementById('FName');
const sName = document.getElementById('SName');
const email = document.getElementById('email');
const UID = document.getElementById('UID');
const phoneNumber= document.getElementById('phoneNumber');
const referenceCode= document.getElementById('reference');
    
form.addEventListener('click',(x) =>{   
    validateForm(x)         
});


function validateForm(x){
    const fNameVal = fName.value.trim();
    const sNameVal = sName.value.trim();
    const emailVal = email.value.trim();
    const UIDVal = UID.value.trim();
    const phoneNumberVal = phoneNumber.value.trim();
    const referenceCodeVal = referenceCode.value.trim();
    const Letters = /^[A-Za-z]+$/;
    let submit = 0; 
        
    if(fNameVal.match(Letters) && fNameVal != "")
    {
        document.getElementById('usernameSuccessIcon').style.visibility = 'visible';
        document.getElementById('usernameErrorIcon').style.visibility = 'hidden';
        submit += 1;
    }
    else
    {
        document.getElementById('usernameSuccessIcon').style.visibility = 'hidden';
        document.getElementById('usernameErrorIcon').style.visibility = 'visible';
         
    }

    if(sNameVal.match(Letters) && sNameVal != "")
    {  
        document.getElementById('lastnameSuccessIcon').style.visibility = 'visible';
        document.getElementById('lastnameErrorIcon').style.visibility = 'hidden';   
    }
    else
    {
        document.getElementById('lastnameSuccessIcon').style.visibility = 'hidden';
        document.getElementById('lastnameErrorIcon').style.visibility = 'visible';
        submit += 1;
    }

    if (emailVal === '' || emailVal.indexOf('@') === -1 || emailVal.indexOf('.') === -1) {
        document.getElementById('emailSuccessIcon').style.visibility = 'hidden';
        document.getElementById('emailErrorIcon').style.visibility = 'visible';
        submit += 1;
    } else {
        document.getElementById('emailSuccessIcon').style.visibility = 'visible';
        document.getElementById('emailErrorIcon').style.visibility = 'hidden';
    }

    if (UIDVal === '') {
        document.getElementById('useridSuccessIcon').style.visibility = 'hidden';
        document.getElementById('lockPIC').style.visibility = 'visible';   
        submit += 1;
    } else {
        document.getElementById('useridSuccessIcon').style.visibility = 'visible';
        document.getElementById('lockPIC').style.visibility = 'hidden';
    }

    if (phoneNumberVal.length != 10 || (phoneNumberVal[0]!= 0)) {
        document.getElementById('phoneSuccessIcon').style.visibility = 'hidden';
        document.getElementById('phoneErrorIcon').style.visibility = 'visible';  
        submit += 1;  
    }else{
        document.getElementById('phoneSuccessIcon').style.visibility = 'visible';
        document.getElementById('phoneErrorIcon').style.visibility = 'hidden';   
    }

    if (referenceCodeVal === '') {
        document.getElementById('refcodeSuccessIcon').style.visibility = 'hidden';
        document.getElementById('refcodeErrorIcon').style.visibility = 'visible'; 
        submit += 1;     
    }else{
        document.getElementById('refcodeSuccessIcon').style.visibility = 'visible';
        document.getElementById('refcodeErrorIcon').style.visibility = 'hidden';   
    }
  
}